This folder contains files for installing programs required by the DOCUFILE database application.
If the files are not already present they will be downloaded from the distributors' websites.

gs9561w64.exe					GhostScript (64-bit) - Postscript interpreter
ImageMagick-7.1.1-41-Q16-HDRI-x64-dll.exe	ImageMagick (64-bit) - Pdf to image file converter 
tesseract-ocr-w64-setup-5.5.0.20241111.exe	Tesseract (64-bit) - OCR engine.

If you run OCRTesseract before these programs are installed on this computer, you'll receive 
warning messages and will not be able to use the application until they are installed.
